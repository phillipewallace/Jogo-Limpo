
import { Search, Globe, Shield, Smartphone } from "lucide-react";

const HowToVerify = () => {
  const steps = [
    {
      icon: Search,
      title: "1. Procure a Fonte Original",
      description: "Veja se a notícia está no site oficial do clube, atleta ou entidade esportiva",
      tip: "Sites oficiais sempre têm o símbolo de verificação ou domínio oficial"
    },
    {
      icon: Globe,
      title: "2. Consulte Vários Sites",
      description: "Se for verdade, outros sites de esporte confiáveis também vão noticiar",
      tip: "ESPN, GloboEsporte, UOL Esporte são fontes confiáveis"
    },
    {
      icon: Shield,
      title: "3. Use Sites de Verificação",
      description: "Consulte sites especializados em checagem de fatos",
      tip: "Lupa, Aos Fatos, Fato ou Fake são recursos gratuitos"
    },
    {
      icon: Smartphone,
      title: "4. Verifique Redes Sociais Oficiais",
      description: "Perfis verificados de clubes e atletas nas redes sociais",
      tip: "Procure pelo selo azul de verificação"
    }
  ];

  const reliableSites = [
    { name: "Lupa", url: "https://lupa.uol.com.br" },
    { name: "Aos Fatos", url: "https://aosfatos.org" },
    { name: "Fato ou Fake", url: "https://g1.globo.com/fato-ou-fake" },
    { name: "Boatos.org", url: "https://boatos.org" }
  ];

  return (
    <section id="how-to-verify" className="py-16 bg-blue-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Search className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Como Verificar uma Notícia
            </h2>
            <p className="text-lg text-gray-600">
              Guia prático para checagem de informações esportivas
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {steps.map((step, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <step.icon className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {step.title}
                    </h3>
                    <p className="text-gray-700 mb-3">{step.description}</p>
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <p className="text-sm text-blue-700">
                        <strong>Dica:</strong> {step.tip}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-lg shadow-md p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              Sites Confiáveis para Verificação
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              {reliableSites.map((site, index) => (
                <div key={index} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                  <Shield className="h-8 w-8 text-green-600" />
                  <div>
                    <h4 className="font-semibold text-gray-900">{site.name}</h4>
                    <p className="text-sm text-gray-600">{site.url}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Regra de Ouro</h3>
            <p className="text-xl mb-4">
              "Na dúvida, não compartilhe!"
            </p>
            <p className="text-blue-100">
              É melhor não compartilhar uma notícia verdadeira do que espalhar uma mentira.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowToVerify;
