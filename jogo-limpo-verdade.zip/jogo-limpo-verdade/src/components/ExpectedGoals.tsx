
import { Target, Users, Shield, BookOpen } from "lucide-react";

const ExpectedGoals = () => {
  const goals = [
    {
      icon: Shield,
      title: "Responsabilidade Digital",
      description: "Promover uma cultura de responsabilidade digital entre jovens e educadores",
      color: "text-blue-600"
    },
    {
      icon: BookOpen,
      title: "Senso Crítico",
      description: "Estimular o senso crítico de jovens, educadores e familiares",
      color: "text-green-600"
    },
    {
      icon: Users,
      title: "Ética Esportiva",
      description: "Fortalecer a ética no ambiente esportivo e digital",
      color: "text-purple-600"
    }
  ];

  return (
    <section id="expected-goals" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Target className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Objetivos Esperados</h2>
            <p className="text-lg text-gray-600">
              Com essas iniciativas, esperamos alcançar:
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {goals.map((goal, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6 text-center">
                <goal.icon className={`h-12 w-12 ${goal.color} mx-auto mb-4`} />
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{goal.title}</h3>
                <p className="text-gray-700 leading-relaxed">{goal.description}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-lg p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Impacto Esperado</h3>
            <p className="text-lg leading-relaxed max-w-2xl mx-auto">
              Através da educação e conscientização, podemos criar uma geração mais crítica e responsável 
              no consumo e compartilhamento de informações esportivas.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExpectedGoals;
