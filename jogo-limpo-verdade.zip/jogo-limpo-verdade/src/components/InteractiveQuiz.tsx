
import { useState } from "react";
import { CheckCircle, XCircle, RotateCcw } from "lucide-react";

const InteractiveQuiz = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);

  const questions = [
    {
      question: "Você vê uma notícia sobre um jogador famoso se transferindo para um clube. O que fazer primeiro?",
      options: [
        "Compartilhar imediatamente com os amigos",
        "Verificar se o clube oficial confirmou",
        "Procurar a notícia em redes sociais",
        "Acreditar se muitas pessoas compartilharam"
      ],
      correctAnswer: 1,
      explanation: "Sempre verifique fontes oficiais antes de compartilhar qualquer notícia."
    },
    {
      question: "Uma notícia sobre lesão de atleta está circulando. Como saber se é verdade?",
      options: [
        "Se está em um site conhecido, é verdade",
        "Conferir no perfil oficial do atleta ou clube",
        "Perguntar para outros torcedores",
        "Se tem foto, deve ser verdade"
      ],
      correctAnswer: 1,
      explanation: "Perfis oficiais verificados são as melhores fontes para confirmar informações sobre atletas."
    },
    {
      question: "Você recebe uma mensagem sobre peneira gratuita em clube famoso. O que fazer?",
      options: [
        "Inscrever-se imediatamente",
        "Verificar no site oficial do clube",
        "Compartilhar com outros pais",
        "Ligar para o número fornecido"
      ],
      correctAnswer: 1,
      explanation: "Muitos golpes usam peneiras falsas. Sempre confirme no site oficial do clube."
    },
    {
      question: "Qual é a principal característica de uma fake news no esporte?",
      options: [
        "Sempre tem imagens falsas",
        "Apela para emoções e gera revolta",
        "É publicada apenas em redes sociais",
        "Sempre fala sobre transferências"
      ],
      correctAnswer: 1,
      explanation: "Fake news geralmente exploram emoções fortes como raiva, medo ou euforia para se espalharem rapidamente."
    },
    {
      question: "O que fazer ao encontrar uma informação duvidosa sobre seu time?",
      options: [
        "Compartilhar para que outros vejam",
        "Ignorar completamente",
        "Verificar em múltiplas fontes confiáveis",
        "Perguntar apenas para outros torcedores"
      ],
      correctAnswer: 2,
      explanation: "A verificação cruzada em múltiplas fontes confiáveis é a melhor forma de confirmar informações."
    },
    {
      question: "Qual desses é um sinal de que uma notícia pode ser falsa?",
      options: [
        "Tem data e local específicos",
        "Cita fontes oficiais verificadas",
        "Usa linguagem sensacionalista e urgente",
        "Está em um site de notícias conhecido"
      ],
      correctAnswer: 2,
      explanation: "Linguagem sensacionalista, títulos em maiúsculas e urgência excessiva são sinais de alerta."
    },
    {
      question: "Como identificar uma fonte confiável no esporte?",
      options: [
        "Tem muitos seguidores nas redes sociais",
        "Possui selo de verificação e histórico jornalístico",
        "Publica notícias exclusivas sempre",
        "Usa muitas imagens e vídeos"
      ],
      correctAnswer: 1,
      explanation: "Fontes confiáveis têm credenciais verificadas, histórico jornalístico sólido e seguem padrões éticos."
    },
    {
      question: "O que fazer se você já compartilhou uma fake news sem saber?",
      options: [
        "Deixar como está, ninguém vai notar",
        "Apagar e fingir que não aconteceu",
        "Corrigir publicamente e explicar o erro",
        "Compartilhar outra notícia para distrair"
      ],
      correctAnswer: 2,
      explanation: "A transparência e correção pública demonstram responsabilidade e ajudam a educar outros."
    }
  ];

  const handleAnswer = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    if (answerIndex === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
      setShowResult(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setSelectedAnswer(null);
  };

  const getScoreMessage = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage >= 80) return "Excelente! Você está preparado para identificar fake news!";
    if (percentage >= 60) return "Bom trabalho! Continue praticando a verificação.";
    return "Que tal revisar as dicas? A prática leva à perfeição!";
  };

  if (showResult) {
    return (
      <section className="py-16 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <div className="mb-6">
                {score >= 2 ? (
                  <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                ) : (
                  <XCircle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
                )}
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  Quiz Finalizado!
                </h2>
                <div className="text-6xl font-bold text-purple-600 mb-4">
                  {score}/{questions.length}
                </div>
                <p className="text-lg text-gray-700 mb-6">
                  {getScoreMessage()}
                </p>
              </div>
              
              <button 
                onClick={resetQuiz}
                className="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors flex items-center space-x-2 mx-auto"
              >
                <RotateCcw className="h-5 w-5" />
                <span>Tentar Novamente</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="interactive-quiz" className="py-16 bg-gradient-to-br from-purple-50 to-pink-50">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Teste Seus Conhecimentos
            </h2>
            <p className="text-lg text-gray-600">
              Questão {currentQuestion + 1} de {questions.length}
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="mb-6">
              <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                <div 
                  className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                ></div>
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-6">
                {questions[currentQuestion].question}
              </h3>
              
              <div className="space-y-3">
                {questions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswer(index)}
                    disabled={selectedAnswer !== null}
                    className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                      selectedAnswer === index
                        ? index === questions[currentQuestion].correctAnswer
                          ? 'border-green-500 bg-green-50 text-green-800'
                          : 'border-red-500 bg-red-50 text-red-800'
                        : selectedAnswer !== null && index === questions[currentQuestion].correctAnswer
                        ? 'border-green-500 bg-green-50 text-green-800'
                        : 'border-gray-200 hover:border-purple-300 hover:bg-purple-50'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>

            {selectedAnswer !== null && (
              <div className="mt-6">
                <div className="bg-blue-50 p-4 rounded-lg mb-4">
                  <p className="text-blue-800">
                    <strong>Explicação:</strong> {questions[currentQuestion].explanation}
                  </p>
                </div>
                
                <button
                  onClick={nextQuestion}
                  className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors"
                >
                  {currentQuestion < questions.length - 1 ? 'Próxima Pergunta' : 'Ver Resultado'}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default InteractiveQuiz;
