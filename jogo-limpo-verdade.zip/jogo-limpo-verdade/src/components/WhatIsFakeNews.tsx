
import { AlertTriangle, Target, Zap } from "lucide-react";

const WhatIsFakeNews = () => {
  return (
    <section id="what-is-fake-news" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-6">O Que é Fake News?</h2>
          </div>

          <div className="bg-red-50 border-l-4 border-red-500 rounded-lg p-8 mb-8">
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              <strong className="text-red-600">Fake news</strong> são notícias falsas criadas para enganar, 
              manipular ou influenciar comportamentos. No esporte, esse tipo de desinformação pode gerar 
              boatos sobre lesões, transferências, comportamentos inadequados de atletas ou promessas falsas 
              de oportunidades.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              Isso pode prejudicar a reputação de jogadores, clubes e projetos sociais.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-gray-50 rounded-lg p-6">
              <Target className="h-10 w-10 text-red-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Tipos Comuns no Esporte</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  Boatos sobre lesões de atletas
                </li>
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  Transferências inventadas
                </li>
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  Comportamentos inadequados falsos
                </li>
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  Promessas falsas de oportunidades
                </li>
              </ul>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <Zap className="h-10 w-10 text-orange-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Impactos Negativos</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="text-orange-500 mr-2">•</span>
                  Prejuízo à reputação de atletas
                </li>
                <li className="flex items-start">
                  <span className="text-orange-500 mr-2">•</span>
                  Danos a clubes e projetos sociais
                </li>
                <li className="flex items-start">
                  <span className="text-orange-500 mr-2">•</span>
                  Expectativas irreais criadas
                </li>
                <li className="flex items-start">
                  <span className="text-orange-500 mr-2">•</span>
                  Conflitos desnecessários
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhatIsFakeNews;
