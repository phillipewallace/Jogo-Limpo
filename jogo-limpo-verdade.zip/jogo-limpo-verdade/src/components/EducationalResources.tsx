
import { Download, Video, BookOpen, Share2 } from "lucide-react";

const EducationalResources = () => {
  const resources = [
    {
      type: "PDF",
      title: "Guia Prático: Como Identificar Fake News",
      description: "Material completo com exemplos e dicas para toda a família",
      icon: Download,
      color: "text-red-600",
      bgColor: "bg-red-100"
    },
    {
      type: "Vídeo",
      title: "Série: Fake News no Esporte",
      description: "5 vídeos curtos explicando os principais tipos de desinformação",
      icon: Video,
      color: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      type: "Cartilha",
      title: "Educação Digital para Jovens Atletas",
      description: "Material educativo especial para categorias de base",
      icon: BookOpen,
      color: "text-green-600",
      bgColor: "bg-green-100"
    },
    {
      type: "Templates",
      title: "Frases para Redes Sociais",
      description: "Conteúdo pronto para compartilhar conscientização",
      icon: Share2,
      color: "text-purple-600",
      bgColor: "bg-purple-100"
    }
  ];

  const phrases = [
    "Compartilhou sem checar? Pode ser fake! 🚫",
    "No esporte, a verdade é o melhor jogo ⚽",
    "Antes de compartilhar, sempre verificar 🔍",
    "Fake news não marca gol! ⚽❌",
    "Jogue limpo: compartilhe só verdades ✅"
  ];

  return (
    <section id="educational-resources" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <BookOpen className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Recursos Educacionais
            </h2>
            <p className="text-lg text-gray-600">
              Materiais gratuitos para educadores, pais e comunidade
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {resources.map((resource, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start space-x-4">
                  <div className={`${resource.bgColor} p-3 rounded-lg`}>
                    <resource.icon className={`h-6 w-6 ${resource.color}`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className={`text-xs font-semibold ${resource.color} bg-gray-100 px-2 py-1 rounded`}>
                        {resource.type}
                      </span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {resource.title}
                    </h3>
                    <p className="text-gray-700 mb-4">{resource.description}</p>
                    <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors">
                      Baixar Recurso
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-lg shadow-md p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              Frases Prontas para Compartilhar
            </h3>
            <div className="grid md:grid-cols-1 gap-4">
              {phrases.map((phrase, index) => (
                <div key={index} className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg flex items-center justify-between">
                  <span className="text-gray-800 font-medium">{phrase}</span>
                  <button className="text-blue-600 hover:text-blue-800 p-2">
                    <Share2 className="h-5 w-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-lg p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Kit do Educador</h3>
            <p className="text-lg mb-6">
              Pacote completo com todos os materiais para trabalhar o tema em escolas e projetos sociais
            </p>
            <button className="bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Solicitar Kit Completo
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EducationalResources;
