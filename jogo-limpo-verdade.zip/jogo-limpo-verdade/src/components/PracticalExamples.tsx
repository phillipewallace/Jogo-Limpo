
import { AlertCircle, CheckCircle, XCircle } from "lucide-react";

const PracticalExamples = () => {
  const examples = [
    {
      title: "Lesão Inventada",
      fakeNews: "Jogador X está fora por 6 meses devido a lesão grave",
      reality: "Jogador estava apenas descansando por precaução",
      impact: "Torcedores ficaram preocupados desnecessariamente",
      verification: "Sempre consultar fontes oficiais do clube"
    },
    {
      title: "Transferência Falsa",
      fakeNews: "Atleta Y vai para clube europeu por R$ 50 milhões",
      reality: "Negociação nunca existiu, apenas especulação",
      impact: "Expectativas irreais na comunidade",
      verification: "Aguardar confirmação oficial dos clubes"
    },
    {
      title: "Oportunidade Falsa",
      fakeNews: "Peneira aberta para jovens em clube famoso",
      reality: "Golpe para cobrar taxas de inscrição",
      impact: "Famílias perderam dinheiro e tempo",
      verification: "Verificar se o clube realmente está realizando peneiras"
    }
  ];

  return (
    <section id="practical-examples" className="py-16 bg-yellow-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <AlertCircle className="h-12 w-12 text-yellow-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Exemplos Reais de Fake News no Esporte
            </h2>
            <p className="text-lg text-gray-600">
              Conheça casos que já aconteceram e aprenda a identificar padrões
            </p>
          </div>

          <div className="space-y-8">
            {examples.map((example, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  {example.title}
                </h3>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <XCircle className="h-5 w-5 text-red-500 mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium text-red-700 mb-2">Fake News:</h4>
                        <p className="text-gray-700 italic">"{example.fakeNews}"</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium text-green-700 mb-2">Realidade:</h4>
                        <p className="text-gray-700">{example.reality}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="bg-orange-50 p-4 rounded-lg">
                      <h4 className="font-medium text-orange-700 mb-2">Impacto:</h4>
                      <p className="text-gray-700">{example.impact}</p>
                    </div>
                    
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h4 className="font-medium text-blue-700 mb-2">Como Verificar:</h4>
                      <p className="text-gray-700">{example.verification}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 bg-gradient-to-r from-yellow-500 to-orange-500 text-white rounded-lg p-6 text-center">
            <p className="text-lg font-semibold mb-2">
              Lembre-se: Sempre desconfie de informações que causam forte emoção!
            </p>
            <p className="text-yellow-100">
              Se a notícia te deixou muito animado ou preocupado, pare e verifique antes de compartilhar.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PracticalExamples;
