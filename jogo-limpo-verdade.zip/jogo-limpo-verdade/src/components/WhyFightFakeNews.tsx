
import { Heart, Shield, Users, Zap } from "lucide-react";

const WhyFightFakeNews = () => {
  return (
    <section id="why-fight" className="py-16 bg-gradient-to-r from-green-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Shield className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Por que o Combate às Fake News é Importante no Esporte?
            </h2>
          </div>

          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              O esporte envolve <strong className="text-green-600">paixão, torcida e emoção</strong>. 
              Informações falsas podem acirrar ânimos, espalhar preconceitos, causar conflitos ou 
              alimentar expectativas irreais.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              Para quem trabalha com a base e com projetos sociais, é fundamental proteger a imagem 
              dos envolvidos e manter um ambiente saudável e educativo.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <Heart className="h-10 w-10 text-red-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Riscos das Fake News</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  Acirramento de ânimos desnecessários
                </li>
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  Propagação de preconceitos
                </li>
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  Conflitos entre torcedores
                </li>
                <li className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  Expectativas irreais criadas
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <Users className="h-10 w-10 text-green-600 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Benefícios do Combate</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">•</span>
                  Proteção da imagem dos atletas
                </li>
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">•</span>
                  Ambiente esportivo saudável
                </li>
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">•</span>
                  Educação digital responsável
                </li>
                <li className="flex items-start">
                  <span className="text-green-600 mr-2">•</span>
                  Fortalecimento da comunidade
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyFightFakeNews;
