
import { BookOpen, Heart, Users } from "lucide-react";

const IntroSection = () => {
  return (
    <section id="intro-section" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <BookOpen className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Introdução</h2>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              No nosso projeto social de futebol, não formamos apenas atletas: também buscamos contribuir com a 
              <strong className="text-blue-600"> formação cidadã</strong>. Com o avanço das tecnologias e redes sociais, 
              surgiu um novo desafio — as fake news.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              Mais do que um problema mundial, elas agora impactam diretamente a vida de jovens jogadores, suas famílias 
              e comunidades. Pensando nisso, desenvolvemos uma proposta de conscientização sobre a desinformação no esporte.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <Users className="h-10 w-10 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Jovens Atletas</h3>
              <p className="text-gray-600">Protegemos a imagem e futuro dos nossos jovens jogadores</p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <Heart className="h-10 w-10 text-red-500 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Famílias</h3>
              <p className="text-gray-600">Orientamos pais e responsáveis sobre os riscos digitais</p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <Users className="h-10 w-10 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Comunidades</h3>
              <p className="text-gray-600">Fortalecemos o ambiente esportivo saudável</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default IntroSection;
