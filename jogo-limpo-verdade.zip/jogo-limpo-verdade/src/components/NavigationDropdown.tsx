import { useState } from "react";
import { Menu, X, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const NavigationDropdown = () => {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsOpen(false);
    }
  };

  const menuItems = [
    { id: "intro-section", label: "Introdução" },
    { id: "what-is-fake-news", label: "O que são Fake News?" },
    { id: "why-fight", label: "Por que Combater?" },
    { id: "practical-examples", label: "Exemplos Práticos" },
    { id: "how-to-verify", label: "Como Verificar" },
    { id: "interactive-quiz", label: "Quiz Interativo" },
    { id: "community-impact", label: "Impacto na Comunidade" },
    { id: "expected-goals", label: "Objetivos Esperados" },
    { id: "educational-resources", label: "Recursos Educacionais" },
    { id: "call-to-action", label: "Como Aplicar" },
  ];

  return (
    <div className="fixed top-4 right-4 z-50">
      <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            className="bg-white/90 backdrop-blur-sm border-2 border-primary/20 hover:bg-primary hover:text-white transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            <Menu className="h-5 w-5 mr-2" />
            Navegação
            <ChevronDown className="h-4 w-4 ml-2 transition-transform duration-200" 
              style={{ transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)' }} 
            />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent 
          className="w-56 bg-white/95 backdrop-blur-md border-2 border-primary/20 shadow-xl"
          align="end"
        >
          {menuItems.map((item) => (
            <DropdownMenuItem
              key={item.id}
              onClick={() => scrollToSection(item.id)}
              className="cursor-pointer hover:bg-primary/10 focus:bg-primary/10 transition-colors duration-200 py-3"
            >
              {item.label}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default NavigationDropdown;