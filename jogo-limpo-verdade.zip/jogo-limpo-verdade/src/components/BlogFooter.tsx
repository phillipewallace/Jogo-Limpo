
import { Heart, Shield, Users } from "lucide-react";

const BlogFooter = () => {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Shield className="h-16 w-16 text-blue-400 mx-auto mb-6" />
            
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-8">
              <p className="text-2xl font-bold text-white mb-4">
                "No futebol e na vida, quem joga limpo vence com verdade."
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="text-center">
              <Heart className="h-8 w-8 text-red-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Paixão</h3>
              <p className="text-gray-400">Pelo esporte e pela verdade</p>
            </div>
            <div className="text-center">
              <Users className="h-8 w-8 text-green-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Comunidade</h3>
              <p className="text-gray-400">Fortalecendo laços através da educação</p>
            </div>
            <div className="text-center">
              <Shield className="h-8 w-8 text-blue-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Responsabilidade</h3>
              <p className="text-gray-400">Digital e social</p>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8 text-center">
            <p className="text-gray-400 mb-2">
              Blog educativo sobre combate às fake news no esporte
            </p>
            <p className="text-gray-500 text-sm">
              Desenvolvido com base nos princípios da disciplina APEX II - Faculdade Unyleya
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default BlogFooter;
