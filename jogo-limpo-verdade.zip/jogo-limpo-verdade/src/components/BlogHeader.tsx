
import { Shield, Users, Target } from "lucide-react";

const BlogHeader = () => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center mb-6">
            <Shield className="h-16 w-16 text-blue-200" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
            Fake News no Esporte: Como Combater a Mentira com Consciência Digital
          </h1>
          <p className="text-xl md:text-2xl text-blue-100 leading-relaxed max-w-3xl mx-auto">
            Formando não apenas atletas, mas também cidadãos conscientes na era digital
          </p>
        </div>
      </div>
    </header>
  );
};

export default BlogHeader;
