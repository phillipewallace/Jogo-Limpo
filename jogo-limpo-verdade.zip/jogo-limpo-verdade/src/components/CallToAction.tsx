
import { Users, Smartphone, Globe, Heart } from "lucide-react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const CallToAction = () => {
  const projectImages = [
    "/lovable-uploads/abe72eaf-f2b6-4c08-93ce-cb98edd60d04.png",
    "/lovable-uploads/5d24abd1-ff5c-4fcf-b30b-586cc1cf112e.png",
    "/lovable-uploads/bb1cd3a0-604a-433c-b8b2-b8b6f79c8ba6.png",
    "/lovable-uploads/ef0c4dba-d72a-4675-9bb1-db32ccefa3ad.png",
    "/lovable-uploads/116190da-904f-4070-9642-9c488d5828cc.png",
    "/lovable-uploads/f4e0c0e4-c36a-45b3-9506-52e119ded28d.png",
    "/lovable-uploads/60caf59d-a16b-48fd-8f9c-15352f531ebe.png",
    "/lovable-uploads/7120b206-8cbf-492d-885a-c1ffc27750e9.png",
    "/lovable-uploads/be7bf949-6c69-47f2-a9f3-e9c6df330d4b.png",
    "/lovable-uploads/3e8726d7-b4bc-479a-bdab-d31414efd0c9.png",
    "/lovable-uploads/e5258595-329c-474a-a093-06e8c0d6c3be.png",
  ];

  return (
    <section id="call-to-action" className="py-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Users className="h-12 w-12 text-white mx-auto mb-4" />
            <h2 className="text-3xl font-bold mb-6">Você Também Pode Aplicar!</h2>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto">
              Se você lidera um projeto social, uma escola ou trabalha com jovens, 
              essas ações são acessíveis e impactantes.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="text-center">
              <Globe className="h-12 w-12 text-blue-200 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">Alcance Digital</h3>
              <p className="text-blue-100">
                Sua voz pode alcançar a comunidade através de conteúdos digitais
              </p>
            </div>
            <div className="text-center">
              <Smartphone className="h-12 w-12 text-blue-200 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">Ferramentas Simples</h3>
              <p className="text-blue-100">
                Use redes sociais e plataformas digitais para educar
              </p>
            </div>
            <div className="text-center">
              <Heart className="h-12 w-12 text-blue-200 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">Impacto Real</h3>
              <p className="text-blue-100">
                Cada ação educativa pode transformar vidas
              </p>
            </div>
          </div>

          {/* Carrossel de Fotos do Projeto */}
          <div className="bg-white bg-opacity-10 rounded-lg p-8 mb-8">
            <h3 className="text-2xl font-bold mb-6 text-center">Projeto em Ação</h3>
            <p className="text-lg text-blue-100 mb-8 text-center">
              Veja como aplicamos esses conceitos na prática com jovens da comunidade
            </p>
            
            <Carousel className="w-full max-w-4xl mx-auto">
              <CarouselContent>
                {projectImages.map((image, index) => (
                  <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
                    <div className="p-1">
                      <div className="bg-white bg-opacity-20 rounded-lg overflow-hidden hover:bg-opacity-30 transition-all duration-300">
                        <img
                          src={image}
                          alt={`Projeto educativo sobre fake news - Foto ${index + 1}`}
                          className="w-full h-64 object-cover"
                        />
                      </div>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="bg-white/20 border-white/30 text-white hover:bg-white/30" />
              <CarouselNext className="bg-white/20 border-white/30 text-white hover:bg-white/30" />
            </Carousel>
          </div>

          <div className="bg-white bg-opacity-10 rounded-lg p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Comece Agora</h3>
            <p className="text-lg text-blue-100 mb-6">
              Combater a desinformação começa com educação, intenção e clareza. 
              Mesmo sem um contato direto, você pode fazer a diferença.
            </p>
            <div className="bg-white bg-opacity-20 rounded-lg p-6 inline-block">
              <p className="text-xl font-semibold">
                "A educação é a arma mais poderosa que você pode usar para mudar o mundo."
              </p>
              <p className="text-blue-200 mt-2">- Nelson Mandela</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;
