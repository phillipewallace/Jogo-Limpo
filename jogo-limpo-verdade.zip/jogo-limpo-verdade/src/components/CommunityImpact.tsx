
import { Heart, Users, TrendingUp, Award } from "lucide-react";

const CommunityImpact = () => {
  const impacts = [
    {
      icon: Heart,
      title: "Proteção dos Jovens",
      description: "Evitamos que crianças e adolescentes sejam enganados por promessas falsas",
      stat: "85%",
      statDescription: "dos jovens não sabem identificar fake news"
    },
    {
      icon: Users,
      title: "Fortalecimento Familiar",
      description: "Famílias mais preparadas para orientar seus filhos no mundo digital",
      stat: "90%",
      statDescription: "dos pais se sentem inseguros sobre redes sociais"
    },
    {
      icon: TrendingUp,
      title: "Melhoria da Comunidade",
      description: "Ambiente esportivo mais saudável e baseado em informações verdadeiras",
      stat: "70%",
      statDescription: "dos conflitos são causados por desinformação"
    },
    {
      icon: Award,
      title: "Formação Cidadã",
      description: "Jovens mais críticos e responsáveis na era digital",
      stat: "60%",
      statDescription: "dos brasileiros já compartilharam fake news"
    }
  ];

  return (
    <section id="community-impact" className="py-16 bg-gradient-to-br from-green-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Impacto na Nossa Comunidade
            </h2>
            <p className="text-lg text-gray-600">
              Veja como combater fake news transforma nossa comunidade esportiva
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {impacts.map((impact, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <impact.icon className="h-8 w-8 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {impact.title}
                    </h3>
                    <p className="text-gray-700 mb-4">{impact.description}</p>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="text-3xl font-bold text-green-600 mb-1">
                        {impact.stat}
                      </div>
                      <p className="text-sm text-green-700">{impact.statDescription}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-lg shadow-md p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              Histórias da Nossa Comunidade
            </h3>
            
            <div className="space-y-6">
              <div className="bg-blue-50 p-6 rounded-lg">
                <h4 className="font-semibold text-blue-800 mb-2">
                  Tamires, mãe da aluna Caroline
                </h4>
                <p className="text-gray-700 italic">
                  "Incentivou a inclusão digital, além da formação de cidadãos digitais conscientes."
                </p>
              </div>

              <div className="bg-green-50 p-6 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">
                  Ivan, pai do aluno Ítalo
                </h4>
                <p className="text-gray-700 italic">
                  "Houve um aumento do interesse pela tecnologia, despertou o interesse dos alunos 
                  pelo uso consciente e criativo das ferramentas tecnológicas."
                </p>
              </div>

              <div className="bg-purple-50 p-6 rounded-lg">
                <h4 className="font-semibold text-purple-800 mb-2">
                  Rayane, mãe do aluno Lucas
                </h4>
                <p className="text-gray-700 italic">
                  "Tivemos uma linguagem clara e acessível, promovendo uma comunicação eficiente e inclusiva."
                </p>
              </div>

              <div className="bg-orange-50 p-6 rounded-lg">
                <h4 className="font-semibold text-orange-800 mb-2">
                  Avaliação Geral do Projeto
                </h4>
                <p className="text-gray-700 italic">
                  "Todos foram participativos e interessados pelo tema abordado."
                </p>
              </div>
            </div>

            {/* Informações do Projeto */}
            <div className="mt-8 bg-gradient-to-r from-blue-100 to-purple-100 rounded-lg p-6">
              <h4 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                Sobre o Projeto
              </h4>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg p-4">
                  <h5 className="font-semibold text-blue-800 mb-2">Local de Aplicação</h5>
                  <p className="text-gray-700">
                    <strong>Escola Estadual Itália Cautiero Franco</strong><br/>
                    Comunidade do bairro Luar da Pampulha e adjacências
                  </p>
                </div>
                <div className="bg-white rounded-lg p-4">
                  <h5 className="font-semibold text-purple-800 mb-2">Equipe Responsável</h5>
                  <div className="text-gray-700">
                    <p><strong>Alexa</strong> - Instrutora do projeto e aluna Unyleya</p>
                    <p><strong>Ludmila</strong> - Aluna Unyleya e criadora do Blog</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-lg p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Juntos Somos Mais Fortes</h3>
            <p className="text-lg mb-4">
              Cada pessoa que aprende a identificar fake news protege toda a comunidade
            </p>
            <div className="bg-white bg-opacity-20 rounded-lg p-4 inline-block">
              <p className="text-xl font-semibold">
                "Uma mentira pode dar a volta ao mundo enquanto a verdade está calçando os sapatos"
              </p>
              <p className="text-green-200 mt-2">- Provérbio Popular</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CommunityImpact;
