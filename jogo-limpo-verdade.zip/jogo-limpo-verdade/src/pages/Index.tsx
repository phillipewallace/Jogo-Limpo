
import BlogHeader from "@/components/BlogHeader";
import IntroSection from "@/components/IntroSection";
import WhatIsFakeNews from "@/components/WhatIsFakeNews";
import WhyFightFakeNews from "@/components/WhyFightFakeNews";
import PracticalExamples from "@/components/PracticalExamples";
import HowToVerify from "@/components/HowToVerify";
import InteractiveQuiz from "@/components/InteractiveQuiz";
import CommunityImpact from "@/components/CommunityImpact";
import ExpectedGoals from "@/components/ExpectedGoals";
import EducationalResources from "@/components/EducationalResources";
import CallToAction from "@/components/CallToAction";
import BlogFooter from "@/components/BlogFooter";
import NavigationDropdown from "@/components/NavigationDropdown";

const Index = () => {
  return (
    <div className="min-h-screen bg-white">
      <NavigationDropdown />
      <BlogHeader />
      <IntroSection />
      <WhatIsFakeNews />
      <WhyFightFakeNews />
      <PracticalExamples />
      <HowToVerify />
      <InteractiveQuiz />
      <CommunityImpact />
      <ExpectedGoals />
      <EducationalResources />
      <CallToAction />
      <BlogFooter />
    </div>
  );
};

export default Index;
